﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Som4lia_V1
{
    public partial class Form1 : Form
    {
        // --- APIS Y REDONDEO ---
        [DllImport("user32.dll")] static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vKey);
        [DllImport("kernel32.dll")] static extern bool QueryPerformanceCounter(out long lpPerformanceCount);
        [DllImport("kernel32.dll")] static extern bool QueryPerformanceFrequency(out long lpFrequency);
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        // --- VARIABLES ---
        private int leftBind = 0, rightBind = 0, hideBind = 0, toggleBind = 0;
        private bool assigningLeft = false, assigningRight = false, assigningHide = false, assigningToggle = false;
        private bool isHidden = false, clickerEnabled = true;

        private NumericUpDown LMin, LMax, RMin, RMax;
        private Button btnBindL, btnBindR, btnBindHide, btnBindToggle, btnTabMain, btnTabConfig, btnTabPanic;
        private CheckBox chkJitter, chkSafeMode;
        private Panel pnlMain, pnlConfig, pnlPanic, pnlConfirm;
        private Label lblStatus;

        public Form1()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer, true);
            this.DoubleBuffered = true;

            this.Size = new Size(380, 420);
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(15, 15, 15);

            this.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));

            ConfigurarInterfaz();
            IniciarHilos();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using (LinearGradientBrush lgb = new LinearGradientBrush(this.ClientRectangle,
                   Color.FromArgb(15, 15, 15), Color.FromArgb(35, 10, 10), 45f))
            {
                g.FillRectangle(lgb, this.ClientRectangle);
            }

            using (Pen p = new Pen(Color.FromArgb(220, 255, 0, 0), 2))
            {
                g.DrawPath(p, GetRoundedPath(new Rectangle(1, 1, Width - 3, Height - 3), 25));
            }
        }

        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
            path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
            path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
            path.CloseFigure();
            return path;
        }

        private void ConfigurarInterfaz()
        {
            Panel pnlTopBar = new Panel { Dock = DockStyle.Top, Height = 30, BackColor = Color.Transparent };
            Button btnClose = new Button { Text = "✕", Size = new Size(35, 30), Location = new Point(this.Width - 40, 0), FlatStyle = FlatStyle.Flat, ForeColor = Color.White, Cursor = Cursors.Hand };
            btnClose.FlatAppearance.BorderSize = 0; btnClose.Click += (s, e) => Application.Exit();
            pnlTopBar.Controls.Add(btnClose);
            pnlTopBar.MouseDown += (s, e) => { ReleaseCapture(); SendMessage(this.Handle, 0xA1, 0x2, 0); };

            Panel pnlHeader = new Panel { Dock = DockStyle.Top, Height = 55, BackColor = Color.Transparent };
            lblStatus = new Label { Text = "● ACTIVE", Font = new Font("Segoe UI", 7, FontStyle.Bold), ForeColor = Color.Lime, Location = new Point(20, 15), AutoSize = true };
            Label titleMain = new Label { Text = "SOM4LIA", Font = new Font("Segoe UI Black", 20, FontStyle.Italic), ForeColor = Color.Red, AutoSize = true, Location = new Point(90, 5) };
            Label lblVersion = new Label { Text = "v1", Font = new Font("Segoe UI", 8, FontStyle.Bold), ForeColor = Color.FromArgb(100, 100, 100), AutoSize = true, Location = new Point(240, 19) };
            pnlHeader.Controls.AddRange(new Control[] { lblStatus, titleMain, lblVersion });

            Panel tabContainer = new Panel { Dock = DockStyle.Top, Height = 40, BackColor = Color.Transparent };
            btnTabMain = CrearBotonTab("CLICKER", 20);
            btnTabConfig = CrearBotonTab("SETTINGS", 145);
            btnTabPanic = CrearBotonTab("SECURITY", 270);
            btnTabMain.Click += (s, e) => SwitchTab(pnlMain, btnTabMain);
            btnTabConfig.Click += (s, e) => SwitchTab(pnlConfig, btnTabConfig);
            btnTabPanic.Click += (s, e) => SwitchTab(pnlPanic, btnTabPanic);
            tabContainer.Controls.AddRange(new Control[] { btnTabMain, btnTabConfig, btnTabPanic });

            Panel pnlContent = new Panel { Dock = DockStyle.Fill, Padding = new Padding(25, 5, 25, 20), BackColor = Color.Transparent };
            pnlMain = CrearPanelContenido(); pnlConfig = CrearPanelContenido(); pnlPanic = CrearPanelContenido(); pnlConfirm = CrearPanelContenido();
            pnlContent.Controls.AddRange(new Control[] { pnlMain, pnlConfig, pnlPanic, pnlConfirm });

            // --- CLICKER TAB ---
            AgregarLabel(pnlMain, "LEFT CLICKER", 0, 5, Color.Silver, 8);
            AgregarLabel(pnlMain, "MIN CPS", 0, 30, Color.Gray, 7);
            AgregarLabel(pnlMain, "MAX CPS", 170, 30, Color.Gray, 7);
            LMin = CrearNum(pnlMain, 0, 50, 150); LMax = CrearNum(pnlMain, 170, 50, 150);
            btnBindL = CrearBtnAccion(pnlMain, "ASSIGN BIND", 0, 85, 320);
            btnBindL.Click += (s, e) => { assigningLeft = true; btnBindL.Text = "..."; };

            AgregarLabel(pnlMain, "RIGHT CLICKER", 0, 135, Color.Silver, 8);
            AgregarLabel(pnlMain, "MIN CPS", 0, 160, Color.Gray, 7);
            AgregarLabel(pnlMain, "MAX CPS", 170, 160, Color.Gray, 7);
            RMin = CrearNum(pnlMain, 0, 180, 150); RMax = CrearNum(pnlMain, 170, 180, 150);
            btnBindR = CrearBtnAccion(pnlMain, "ASSIGN BIND", 0, 215, 320);
            btnBindR.Click += (s, e) => { assigningRight = true; btnBindR.Text = "..."; };

            // --- SETTINGS TAB ---
            chkJitter = CrearCheck(pnlConfig, "JITTER", 0, 10);
            chkSafeMode = CrearCheck(pnlConfig, "SAFETY MODE (MAX 15 CPS)", 0, 35);
            btnBindToggle = CrearBtnAccion(pnlConfig, "TOGGLE: NONE", 0, 75, 320);
            btnBindToggle.Click += (s, e) => { assigningToggle = true; btnBindToggle.Text = "..."; };
            btnBindHide = CrearBtnAccion(pnlConfig, "HIDE: NONE", 0, 125, 320);
            btnBindHide.Click += (s, e) => { assigningHide = true; btnBindHide.Text = "..."; };

            Button btnGit = CrearBtnAccion(pnlConfig, "GITHUB REPOSITORY", 0, 200, 320);
            btnGit.BackColor = Color.FromArgb(15, 25, 50);
            btnGit.Click += (s, e) => Process.Start(new ProcessStartInfo("https://github.com/ImGoodBath/Som4lia_V1-Minecraft-Bedrock-Autoclick") { UseShellExecute = true });

            // --- SECURITY TAB ---
            AgregarLabel(pnlPanic, "SYSTEM PURGE", 0, 10, Color.Red, 9);
            Label info = new Label { Text = "WARNING: Proceeding will execute a permanent file deletion and self-destruct the binary.", Location = new Point(0, 45), Size = new Size(320, 80), ForeColor = Color.FromArgb(200, 100, 100), Font = new Font("Segoe UI", 8), BackColor = Color.Transparent };
            pnlPanic.Controls.Add(info);
            Button bPanic = CrearBtnAccion(pnlPanic, "EXECUTE CLEANER", 0, 180, 320);
            bPanic.BackColor = Color.FromArgb(40, 5, 5); bPanic.Click += (s, e) => SwitchTab(pnlConfirm, btnTabPanic);

            AgregarLabel(pnlConfirm, "ARE YOU SURE?", 0, 60, Color.Red, 10);
            Button bYes = CrearBtnAccion(pnlConfirm, "YES", 0, 130, 150);
            bYes.Click += (s, e) => SelfDestruct(); // <--- LLAMADA A AUTODESTRUCCIÓN

            Button bNo = CrearBtnAccion(pnlConfirm, "NO", 170, 130, 150);
            bNo.Click += (s, e) => SwitchTab(pnlPanic, btnTabPanic);

            this.Controls.AddRange(new Control[] { pnlContent, tabContainer, pnlHeader, pnlTopBar });
            SwitchTab(pnlMain, btnTabMain);
        }

        // --- MÉTODO DE AUTODESTRUCCIÓN INTEGRADO ---
        private void SelfDestruct()
        {
            string appPath = Application.ExecutablePath;
            string appName = Path.GetFileNameWithoutExtension(appPath);

            // Comando CMD: espera 1 seg, borra el EXE, limpia Registro (RunMRU) y borra Prefetch
            string cmd = $"/C choice /C Y /N /D Y /T 1 & " +
                         $"del /f /q \"{appPath}\" & " +
                         $"reg delete \"HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU\" /f & " +
                         $"del /f /q C:\\Windows\\Prefetch\\{appName.ToUpper()}* & " +
                         $"exit";

            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", cmd)
            {
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true,
                UseShellExecute = false
            };

            Process.Start(psi);
            Application.Exit();
        }

        private void IniciarHilos()
        {
            new Thread(() => {
                while (true)
                {
                    if (clickerEnabled && !IsAssigning())
                    {
                        Random rnd = new Random(); long freq; QueryPerformanceFrequency(out freq);
                        if (leftBind > 0 && (GetAsyncKeyState(leftBind) & 0x8000) != 0) DoClick(rnd, freq, (int)LMin.Value, (int)LMax.Value, true);
                        if (rightBind > 0 && (GetAsyncKeyState(rightBind) & 0x8000) != 0) DoClick(rnd, freq, (int)RMin.Value, (int)RMax.Value, false);
                    }
                    Thread.Sleep(1);
                }
            })
            { IsBackground = true }.Start();

            new Thread(() => {
                while (true)
                {
                    BindingLogic();
                    if (!IsAssigning())
                    {
                        if (toggleBind > 0 && (GetAsyncKeyState(toggleBind) & 0x8000) != 0)
                        {
                            clickerEnabled = !clickerEnabled;
                            this.Invoke(new MethodInvoker(() => {
                                lblStatus.Text = clickerEnabled ? "● ACTIVE" : "● DISABLED";
                                lblStatus.ForeColor = clickerEnabled ? Color.Lime : Color.Gray;
                            }));
                            Thread.Sleep(300);
                        }
                        if (hideBind > 0 && (GetAsyncKeyState(hideBind) & 0x8000) != 0)
                        {
                            isHidden = !isHidden;
                            this.Invoke(new MethodInvoker(() => this.Visible = !isHidden));
                            Thread.Sleep(300);
                        }
                    }
                    Thread.Sleep(15);
                }
            })
            { IsBackground = true }.Start();
        }

        private void BindingLogic()
        {
            if (!IsAssigning()) return;
            for (int i = 1; i < 255; i++)
            {
                if ((GetAsyncKeyState(i) & 0x8000) != 0)
                {
                    int key = i;
                    this.Invoke(new MethodInvoker(() => {
                        if (key == 27)
                        {
                            if (assigningLeft) { leftBind = 0; btnBindL.Text = "ASSIGN BIND"; }
                            else if (assigningRight) { rightBind = 0; btnBindR.Text = "ASSIGN BIND"; }
                            else if (assigningToggle) { toggleBind = 0; btnBindToggle.Text = "TOGGLE: NONE"; }
                            else if (assigningHide) { hideBind = 0; btnBindHide.Text = "HIDE: NONE"; }
                        }
                        else
                        {
                            string name = ((Keys)key).ToString().ToUpper();
                            if (assigningLeft) { leftBind = key; btnBindL.Text = "BIND: " + name; }
                            else if (assigningRight) { rightBind = key; btnBindR.Text = "BIND: " + name; }
                            else if (assigningToggle) { toggleBind = key; btnBindToggle.Text = "TOGGLE: " + name; }
                            else if (assigningHide) { hideBind = key; btnBindHide.Text = "HIDE: " + name; }
                        }
                        assigningLeft = assigningRight = assigningToggle = assigningHide = false;
                    }));
                    Thread.Sleep(400); break;
                }
            }
        }

        private void DoClick(Random rnd, long freq, int min, int max, bool left)
        {
            double cps = rnd.Next(min, max + 1) + rnd.NextDouble();
            if (chkSafeMode.Checked && cps > 15) cps = 15;
            double interval = (double)freq / cps;
            long start; QueryPerformanceCounter(out start);
            mouse_event(left ? 0x02 : 0x08, 0, 0, 0, 0);
            Thread.Sleep(rnd.Next(10, 20));
            mouse_event(left ? 0x04 : 0x10, 0, 0, 0, 0);
            long curr; do { QueryPerformanceCounter(out curr); } while ((curr - start) < interval);
        }

        private bool IsAssigning() => assigningLeft || assigningRight || assigningHide || assigningToggle;

        private Button CrearBotonTab(string t, int x)
        {
            var b = new Button { Text = t, Location = new Point(x, 0), Size = new Size(90, 40), FlatStyle = FlatStyle.Flat, ForeColor = Color.DimGray, Font = new Font("Segoe UI", 7, FontStyle.Bold), BackColor = Color.Transparent, Cursor = Cursors.Hand };
            b.FlatAppearance.BorderSize = 0; b.FlatAppearance.MouseDownBackColor = Color.Transparent; b.FlatAppearance.MouseOverBackColor = Color.FromArgb(20, 255, 255, 255);
            return b;
        }
        private Panel CrearPanelContenido() => new Panel { Dock = DockStyle.Fill, Visible = false, BackColor = Color.Transparent };
        private void AgregarLabel(Panel p, string t, int x, int y, Color c, int size) => p.Controls.Add(new Label { Text = t, Location = new Point(x, y), ForeColor = c, Font = new Font("Segoe UI", size, FontStyle.Bold), AutoSize = true, BackColor = Color.Transparent });
        private CheckBox CrearCheck(Panel p, string t, int x, int y) { var c = new CheckBox { Text = t, Location = new Point(x, y), ForeColor = Color.White, Font = new Font("Segoe UI", 7, FontStyle.Bold), AutoSize = true, FlatStyle = FlatStyle.Flat, BackColor = Color.Transparent }; p.Controls.Add(c); return c; }
        private NumericUpDown CrearNum(Panel p, int x, int y, int w) { var n = new NumericUpDown { Location = new Point(x, y), Size = new Size(w, 20), Minimum = 1, Maximum = 60, Value = 12, BackColor = Color.FromArgb(25, 25, 25), ForeColor = Color.White, BorderStyle = BorderStyle.None }; p.Controls.Add(n); return n; }
        private Button CrearBtnAccion(Panel p, string t, int x, int y, int w) { var b = new Button { Text = t, Location = new Point(x, y), Size = new Size(w, 40), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(30, 30, 30), ForeColor = Color.White, Font = new Font("Segoe UI", 8, FontStyle.Bold), Cursor = Cursors.Hand }; b.FlatAppearance.BorderSize = 0; p.Controls.Add(b); return b; }
        private void SwitchTab(Panel target, Button active) { pnlMain.Visible = pnlConfig.Visible = pnlPanic.Visible = pnlConfirm.Visible = false; btnTabMain.ForeColor = btnTabConfig.ForeColor = btnTabPanic.ForeColor = Color.DimGray; target.Visible = true; active.ForeColor = Color.White; target.BringToFront(); }
    }
}