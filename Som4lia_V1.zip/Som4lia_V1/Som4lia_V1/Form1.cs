﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;

namespace Som4lia_V1
{
    public partial class Form1 : Form
    {
        // --- APIS ---
        [DllImport("user32.dll")] static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vKey);
        [DllImport("kernel32.dll")] static extern bool QueryPerformanceCounter(out long lpPerformanceCount);
        [DllImport("kernel32.dll")] static extern bool QueryPerformanceFrequency(out long lpFrequency);
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        // --- VARIABLES ---
        private int leftBind = 0, rightBind = 0, hideBind = 0;
        private bool assigningLeft = false, assigningRight = false, assigningHide = false;
        private bool isHidden = false, isClicking = false;

        private NumericUpDown LMin, LMax, RMin, RMax;
        private Button btnBindL, btnBindR, btnBindHide, btnTabMain, btnTabGhost, btnTabPanic;
        private CheckBox chkJitter, chkSafeMode;
        private Panel pnlMain, pnlGhost, pnlPanic, pnlConfirm;
        private Label title;

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.ResumeLayout(false);

        }

        public Form1()
        {
            this.Size = new Size(400, 420);
            this.BackColor = Color.FromArgb(15, 15, 15);
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.DoubleBuffered = true; // Mejora el dibujado del borde

            ConfigurarInterfaz();
            IniciarHilos();
        }

        // --- SOLUCIÓN DEL CONTORNO TOTAL ---
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            // Usamos un grosor de 2px y dibujamos ligeramente hacia adentro para asegurar visibilidad
            using (Pen p = new Pen(Color.Red, 2))
            {
                e.Graphics.DrawRectangle(p, 1, 1, this.Width - 2, this.Height - 2);
            }
        }

        private void ConfigurarInterfaz()
        {
            // --- BARRA SUPERIOR ---
            Panel pnlTopBar = new Panel { Dock = DockStyle.Top, Height = 30, BackColor = Color.Transparent };
            Color controlGray = Color.FromArgb(180, 180, 180);

            Button btnClose = new Button { Text = "✕", Size = new Size(30, 28), Dock = DockStyle.Right, FlatStyle = FlatStyle.Flat, ForeColor = controlGray, Font = new Font("Segoe UI", 9), Cursor = Cursors.Hand };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => Application.Exit();

            Button btnMin = new Button { Text = "—", Size = new Size(30, 28), Dock = DockStyle.Right, FlatStyle = FlatStyle.Flat, ForeColor = controlGray, Font = new Font("Segoe UI", 9), Cursor = Cursors.Hand };
            btnMin.FlatAppearance.BorderSize = 0;
            btnMin.Click += (s, e) => this.WindowState = FormWindowState.Minimized;

            pnlTopBar.Controls.AddRange(new Control[] { btnMin, btnClose });
            pnlTopBar.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) { ReleaseCapture(); SendMessage(this.Handle, 0xA1, 0x2, 0); } };

            title = new Label { Text = "SOM4LIA V1", Font = new Font("Impact", 24), ForeColor = Color.Red, Dock = DockStyle.Top, Height = 50, TextAlign = ContentAlignment.MiddleCenter };
            title.MouseDown += (s, e) => { ReleaseCapture(); SendMessage(this.Handle, 0xA1, 0x2, 0); };

            Panel tabContainer = new Panel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(10, 0, 10, 0) };
            btnTabMain = CrearBotonTab("CLICKER", 20);
            btnTabGhost = CrearBotonTab("GHOST", 155);
            btnTabPanic = CrearBotonTab("PANIC", 290);
            btnTabMain.Click += (s, e) => SwitchTab(pnlMain, btnTabMain);
            btnTabGhost.Click += (s, e) => SwitchTab(pnlGhost, btnTabGhost);
            btnTabPanic.Click += (s, e) => SwitchTab(pnlPanic, btnTabPanic);
            tabContainer.Controls.AddRange(new Control[] { btnTabMain, btnTabGhost, btnTabPanic });

            // Contenedor principal para dejar margen al borde rojo
            Panel pnlContent = new Panel { Dock = DockStyle.Fill, Padding = new Padding(3) };
            pnlMain = CrearPanelContenido();
            pnlGhost = CrearPanelContenido();
            pnlPanic = CrearPanelContenido();
            pnlConfirm = CrearPanelContenido();
            pnlContent.Controls.AddRange(new Control[] { pnlMain, pnlGhost, pnlPanic, pnlConfirm });

            // --- CLICKER TAB (Min/Max Labels) ---
            AgregarLabel(pnlMain, "LEFT CPS", 40, 15, Color.Red, 9);
            AgregarLabel(pnlMain, "MIN", 40, 35, Color.Gray, 7);
            LMin = CrearNum(pnlMain, 40, 50);
            AgregarLabel(pnlMain, "MAX", 210, 35, Color.Gray, 7);
            LMax = CrearNum(pnlMain, 210, 50);
            btnBindL = CrearBtnAccion(pnlMain, "BIND LEFT", 40, 85, 320);
            btnBindL.Click += (s, e) => { assigningLeft = true; btnBindL.Text = "WAITING..."; };

            AgregarLabel(pnlMain, "RIGHT CPS", 40, 140, Color.Red, 9);
            AgregarLabel(pnlMain, "MIN", 40, 160, Color.Gray, 7);
            RMin = CrearNum(pnlMain, 40, 175);
            AgregarLabel(pnlMain, "MAX", 210, 160, Color.Gray, 7);
            RMax = CrearNum(pnlMain, 210, 175);
            btnBindR = CrearBtnAccion(pnlMain, "BIND RIGHT", 40, 210, 320);
            btnBindR.Click += (s, e) => { assigningRight = true; btnBindR.Text = "WAITING..."; };

            // --- GHOST TAB ---
            chkJitter = CrearCheck(pnlGhost, "JITTER MODE", 40, 30);
            chkSafeMode = CrearCheck(pnlGhost, "SAFE MODE (MAX 15 CPS)", 40, 65);
            AgregarLabel(pnlGhost, "INTERFACE HOTKEY", 40, 110);
            btnBindHide = CrearBtnAccion(pnlGhost, "NONE", 40, 135, 320);
            btnBindHide.Click += (s, e) => { assigningHide = true; btnBindHide.Text = "WAITING..."; };

            // --- PANIC TAB ---
            Button btnGoToConfirm = CrearBtnAccion(pnlPanic, "P A N I C    B U T T O N", 40, 80, 320);
            btnGoToConfirm.Height = 50; btnGoToConfirm.BackColor = Color.FromArgb(40, 5, 5); btnGoToConfirm.ForeColor = Color.Red;
            btnGoToConfirm.Click += (s, e) => SwitchTab(pnlConfirm, btnTabPanic);
            pnlPanic.Controls.Add(new Label { Text = "WARNING: Clicking this button will prepare the system for full self-destruction. This action is permanent.", Location = new Point(40, 145), Size = new Size(320, 60), ForeColor = Color.FromArgb(160, 0, 0), Font = new Font("Segoe UI", 8, FontStyle.Italic), TextAlign = ContentAlignment.TopCenter });

            // --- CONFIRM TAB (Discord y Mensajes) ---
            AgregarLabel(pnlConfirm, "ARE YOU ABSOLUTELY SURE?", 40, 30, Color.Red, 11);
            Button btnFinalDestruct = CrearBtnAccion(pnlConfirm, "YES, DESTROY EVERYTHING", 40, 75, 320);
            btnFinalDestruct.BackColor = Color.FromArgb(80, 0, 0);
            btnFinalDestruct.Click += (s, e) => FullDestruction();
            Button btnCancel = CrearBtnAccion(pnlConfirm, "NO, GO BACK", 40, 130, 320);
            btnCancel.BackColor = Color.FromArgb(30, 30, 30);
            btnCancel.Click += (s, e) => SwitchTab(pnlPanic, btnTabPanic);
            pnlConfirm.Controls.Add(new Label { Text = "You can request the file again by messaging Discord: adictionn", Location = new Point(20, 200), Size = new Size(360, 50), ForeColor = Color.White, Font = new Font("Segoe UI", 8, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter });

            this.Controls.AddRange(new Control[] { pnlContent, tabContainer, title, pnlTopBar });
            SwitchTab(pnlMain, btnTabMain);
        }

        // --- SOPORTE ---
        private CheckBox CrearCheck(Panel p, string t, int x, int y) { var c = new CheckBox { Text = t, Location = new Point(x, y), ForeColor = Color.White, Font = new Font("Segoe UI", 8, FontStyle.Bold), AutoSize = true, FlatStyle = FlatStyle.Flat }; p.Controls.Add(c); return c; }
        private Button CrearBotonTab(string t, int x) => new Button { Text = t, Location = new Point(x, 0), Size = new Size(90, 25), FlatStyle = FlatStyle.Flat, ForeColor = Color.FromArgb(80, 80, 80), Font = new Font("Segoe UI", 7, FontStyle.Bold), BackColor = Color.Transparent, Cursor = Cursors.Hand };
        private Panel CrearPanelContenido() => new Panel { Dock = DockStyle.Fill, Visible = false };
        private void AgregarLabel(Panel p, string t, int x, int y, Color? c = null, int size = 8) => p.Controls.Add(new Label { Text = t, Location = new Point(x, y), ForeColor = c ?? Color.Red, Font = new Font("Segoe UI", size, FontStyle.Bold), AutoSize = true });
        private NumericUpDown CrearNum(Panel p, int x, int y) { var n = new NumericUpDown { Location = new Point(x, y), Size = new Size(150, 25), Minimum = 1, Maximum = 60, Value = 12, BackColor = Color.FromArgb(25, 25, 25), ForeColor = Color.White, BorderStyle = BorderStyle.None }; p.Controls.Add(n); return n; }
        private Button CrearBtnAccion(Panel p, string t, int x, int y, int w) { var b = new Button { Text = t, Location = new Point(x, y), Size = new Size(w, 35), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(25, 25, 25), ForeColor = Color.White, Font = new Font("Segoe UI", 8), Cursor = Cursors.Hand }; b.FlatAppearance.BorderSize = 0; p.Controls.Add(b); return b; }

        private void SwitchTab(Panel target, Button active)
        {
            pnlMain.Visible = pnlGhost.Visible = pnlPanic.Visible = pnlConfirm.Visible = false;
            btnTabMain.ForeColor = btnTabGhost.ForeColor = btnTabPanic.ForeColor = Color.FromArgb(80, 80, 80);
            target.Visible = true; active.ForeColor = Color.Red;
            target.BringToFront();
        }

        private void IniciarHilos()
        {
            new Thread(BindingLoop) { IsBackground = true }.Start();
            new Thread(ClickerLoop) { IsBackground = true }.Start();
            new Thread(HideLoop) { IsBackground = true }.Start();
            new Thread(VisualEffectLoop) { IsBackground = true }.Start();
        }

        private void ClickerLoop()
        {
            Random rnd = new Random();
            long freq; QueryPerformanceFrequency(out freq);
            while (true)
            {
                bool isL = leftBind != 0 && (GetAsyncKeyState(leftBind) & 0x8000) != 0;
                bool isR = rightBind != 0 && (GetAsyncKeyState(rightBind) & 0x8000) != 0;
                isClicking = isL || isR;
                if (isL && !assigningLeft) DoClick(rnd, freq, (int)LMin.Value, (int)LMax.Value, true);
                if (isR && !assigningRight) DoClick(rnd, freq, (int)RMin.Value, (int)RMax.Value, false);
                Thread.Sleep(1);
            }
        }

        private void DoClick(Random rnd, long freq, int min, int max, bool left)
        {
            if (chkSafeMode.Checked) { if (min > 12) min = 12; if (max > 15) max = 15; }
            double baseCps = rnd.Next(min, max + 1) + (rnd.NextDouble() * 1.5);
            double interval = (double)freq / baseCps;
            long start; QueryPerformanceCounter(out start);
            if (left && chkJitter.Checked) mouse_event(0x0001, rnd.Next(-1, 2), rnd.Next(-1, 2), 0, 0);
            mouse_event(left ? 0x02 : 0x08, 0, 0, 0, 0);
            Thread.Sleep(rnd.Next(15, 35));
            mouse_event(left ? 0x04 : 0x10, 0, 0, 0, 0);
            long curr; do { QueryPerformanceCounter(out curr); } while ((curr - start) < interval);
        }

        private void VisualEffectLoop() { while (true) { if (isClicking) { this.Invoke(new MethodInvoker(() => title.ForeColor = title.ForeColor == Color.Red ? Color.FromArgb(200, 0, 0) : Color.Red)); Thread.Sleep(300); } else { if (title.ForeColor != Color.Red) this.Invoke(new MethodInvoker(() => title.ForeColor = Color.Red)); Thread.Sleep(500); } } }
        private void HideLoop() { while (true) { if (hideBind != 0 && !assigningHide && (GetAsyncKeyState(hideBind) & 0x8000) != 0) { isHidden = !isHidden; this.Invoke(new MethodInvoker(() => { if (isHidden) { this.Hide(); this.ShowInTaskbar = false; } else { this.Show(); this.ShowInTaskbar = true; this.Focus(); } })); Thread.Sleep(500); } Thread.Sleep(20); } }
        private void BindingLoop() { while (true) { if (assigningLeft || assigningRight || assigningHide) { for (int i = 1; i < 255; i++) { if ((GetAsyncKeyState(i) & 0x8000) != 0) { if (i == 1 || i == 2) continue; string name = i == 27 ? "NONE" : ((Keys)i).ToString().ToUpper(); this.Invoke(new MethodInvoker(() => { if (assigningLeft) { leftBind = (i == 27 ? 0 : i); btnBindL.Text = name; assigningLeft = false; } else if (assigningRight) { rightBind = (i == 27 ? 0 : i); btnBindR.Text = name; assigningRight = false; } else if (assigningHide) { hideBind = (i == 27 ? 0 : i); btnBindHide.Text = name; assigningHide = false; Thread.Sleep(600); } })); break; } } } Thread.Sleep(15); } }
        private void FullDestruction() { Process.Start(new ProcessStartInfo("cmd.exe", "/C timeout /T 1 & del /f /q \"" + Application.ExecutablePath + "\"") { WindowStyle = ProcessWindowStyle.Hidden, CreateNoWindow = true }); Application.Exit(); }
    }
}